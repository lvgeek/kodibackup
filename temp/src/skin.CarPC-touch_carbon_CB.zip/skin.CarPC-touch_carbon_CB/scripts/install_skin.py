import os
import xbmc


os.system("sudo /home/pi/install_skin");
